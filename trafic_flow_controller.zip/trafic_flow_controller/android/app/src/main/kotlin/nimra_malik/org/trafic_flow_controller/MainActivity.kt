package nimra_malik.org.trafic_flow_controller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

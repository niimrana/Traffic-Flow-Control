import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

//Colors
const Color kPrimaryColor = Color(0xFFFE6B55); // primary
const Color kSecondaryColor = Color(0xFF05E3C3); //secondary
const Color kTertiaryColor = Color(0xffFFC33E); //tertairy
Color pinFieldColor = const Color(0xffC4C4C4); //pin field color

//padding
const kScreenPadding = EdgeInsets.all(20.0);

class KTextStyle {
  static TextStyle heading = GoogleFonts.poppins(
    fontSize: 36,
    color: Colors.black,
    fontWeight: FontWeight.normal,
  );

  static TextStyle normal = GoogleFonts.poppins(
    fontSize: 16,
    color: Colors.black,
    fontWeight: FontWeight.normal,
  );
}

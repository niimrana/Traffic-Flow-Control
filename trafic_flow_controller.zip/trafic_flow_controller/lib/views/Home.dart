import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:trafic_flow_controller/views/Automation.dart';
import 'package:trafic_flow_controller/views/CongestionManagement.dart';
import 'package:trafic_flow_controller/views/Roads.dart';
import 'package:trafic_flow_controller/views/ViewTraffic.dart';
import 'package:trafic_flow_controller/views/signUpLoginPage.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  var scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
      ),
      key: scaffoldKey,
      drawer: new Drawer(
        child: new ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Column(
                children: [
                  Container(
                    height: 100.h,
                    child: Image(
                      image: AssetImage("assets/images/earth.png"),
                    ),
                  ),
                  Text(
                    'Maps And Navigation',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 19.sp),
                  )
                ],
              ),
              decoration: BoxDecoration(
                color: Colors.grey.shade400,
              ),
            ),
            ListTile(
              title: Text(
                'View Traffic',
                style: TextStyle(color: Colors.black, fontSize: 19.sp),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ViewTraffic()),
                );
              },
            ),
            Divider(
              color: Colors.grey,
            ),
            ListTile(
              title: Text(
                'Signal Control',
                style: TextStyle(color: Colors.black, fontSize: 19.sp),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Home()),
                );
              },
            ),
            Divider(
              color: Colors.grey,
            ),
            ListTile(
              title: Text(
                'Congestion Management',
                style: TextStyle(color: Colors.black, fontSize: 19.sp),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CongestionManagement()),
                );
              },
            ),
            Divider(
              color: Colors.grey,
            ),
            ListTile(
              title: Text(
                'Roads',
                style: TextStyle(color: Colors.black, fontSize: 19.sp),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Roads()),
                );
              },
            ),
            Divider(
              color: Colors.grey,
            ),
            ListTile(
              title: Text(
                'Automation',
                style: TextStyle(color: Colors.black, fontSize: 19.sp),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Automation()),
                );
              },
            ),
            Divider(
              color: Colors.grey,
            ),
            ListTile(
              title: Text(
                'Logout',
                style: TextStyle(color: Colors.black, fontSize: 19.sp),
              ),
              leading: CircleAvatar(
                backgroundColor: Colors.blue,
                child: Icon(
                  Icons.person,
                  color: Colors.white,
                ),
              ),
              trailing: Icon(Icons.logout),
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => SignUpLoginPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding:
            EdgeInsets.only(top: 50.h, left: 20.w, right: 20.w, bottom: 20.h),
        decoration: BoxDecoration(
          color: Colors.white,
          image: DecorationImage(
              image: AssetImage("assets/images/mapImage.png"),
              fit: BoxFit.cover),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  alignment: Alignment.topRight,
                  // margin: EdgeInsets.only(right: 20.w, top: 20.w),
                  width: 40.w,
                  padding: EdgeInsets.all(10.w),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.sp)),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage("assets/images/homeIcon1.png"),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      Image(
                        image: AssetImage("assets/images/compass.png"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Spacer(),
            Text(
              'Siri Suggestion',
              style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
            ),
            Container(
              padding: EdgeInsets.all(10.w),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.sp)),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(10.w),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20.w),
                    ),
                    child: Icon(
                      Icons.car_repair,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    width: 10.w,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Parked Car',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16.sp),
                      ),
                      Text(
                        '290m away, near DHA Phase 1',
                        style: TextStyle(
                            fontWeight: FontWeight.normal, fontSize: 14.sp),
                      ),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 10.h,
            ),
            Container(
              // color: Theme.of(context).primaryColor,
              width: MediaQuery.of(context).size.width,
              child: new Card(
                child: new ListTile(
                  leading: new Icon(Icons.search),
                  title: new TextField(
                    // controller: controller,
                    decoration: new InputDecoration(
                        hintText: 'Search', border: InputBorder.none),
                    // onChanged: onSearchTextChanged,
                  ),
                  trailing: new IconButton(
                    icon: new Icon(Icons.abc_sharp),
                    onPressed: () {
                      // controller.clear();
                      // onSearchTextChanged('');
                    },
                  ),
                ),
              ),
            ),
            Stack(
              children: <Widget>[
                new Center(
                    child: new Column(
                  children: <Widget>[],
                )),
                Positioned(
                  left: 20.w,
                  top: 25.h,
                  child: InkWell(
                      onTap: () {
                        scaffoldKey.currentState?.openDrawer();
                      },
                      child: Icon(
                        Icons.menu,
                        color: Colors.black,
                      )),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

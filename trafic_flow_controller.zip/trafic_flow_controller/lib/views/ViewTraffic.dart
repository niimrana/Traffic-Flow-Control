import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:trafic_flow_controller/views/Home.dart';

class ViewTraffic extends StatefulWidget {
  const ViewTraffic({Key? key}) : super(key: key);

  @override
  State<ViewTraffic> createState() => _ViewTrafficState();
}

class _ViewTrafficState extends State<ViewTraffic> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding:
            EdgeInsets.only(top: 30.h, left: 20.w, right: 20.w, bottom: 20.h),
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/images/mapImage.png"),
              fit: BoxFit.cover),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    padding: EdgeInsets.all(15.w),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.sp),
                        color: Colors.white),
                    child: Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                    ),
                  ),
                ),
                Container(
                  // color: Theme.of(context).primaryColor,
                  width: 250.w,
                  child: new Card(
                    child: new ListTile(
                      leading: new Icon(Icons.search),
                      title: new TextField(
                        // controller: controller,
                        decoration: new InputDecoration(
                            hintText: 'Search', border: InputBorder.none),
                        // onChanged: onSearchTextChanged,
                      ),
                      trailing: new IconButton(
                        icon: new Icon(Icons.abc_sharp),
                        onPressed: () {
                          // controller.clear();
                          // onSearchTextChanged('');
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Spacer(),
                Container(
                  // alignment: Alignment.topRight,
                  // margin: EdgeInsets.only(right: 20.w, top: 20.w),
                  width: 40.w,
                  padding: EdgeInsets.all(10.w),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.sp)),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage("assets/images/homeIcon1.png"),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      Image(
                        image: AssetImage("assets/images/compass.png"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Spacer(),
            Container(
                padding: EdgeInsets.all(10.w),
                width: MediaQuery.of(context).size.width,
                height: 200.h,
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.5),
                    borderRadius: BorderRadius.circular(10.sp)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Container(
                          padding: EdgeInsets.all(15.w),
                          decoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(15.w),
                          ),
                          child: Text(
                            "Low Traffic",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(15.w),
                          decoration: BoxDecoration(
                            color: Colors.orange,
                            borderRadius: BorderRadius.circular(15.w),
                          ),
                          child: Text(
                            "Medium Traffic",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Container(
                          padding: EdgeInsets.all(15.w),
                          decoration: BoxDecoration(
                            color: Colors.pink,
                            borderRadius: BorderRadius.circular(15.w),
                          ),
                          child: Text(
                            "Heavy Traffic",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(15.w),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(15.w),
                          ),
                          child: Text(
                            "Severe Traffic",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ],
                )),
          ],
        ),
      ),
    );
  }
}

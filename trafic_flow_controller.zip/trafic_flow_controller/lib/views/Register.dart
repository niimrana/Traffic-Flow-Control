import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:trafic_flow_controller/views/Home.dart';

class Register extends StatelessWidget {
  const Register({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.blue,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height / 1.7,
              decoration: BoxDecoration(
                  color: Colors.white,
                  image: DecorationImage(
                      image:
                          AssetImage("assets/images/LoginSignUpTitleImage.png"),
                      fit: BoxFit.cover)),
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.all(50.w),
                    child: Text(
                      'Traffic Flow Control',
                      style: TextStyle(
                          fontFamily: 'Poppins-Regular',
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                          color: Colors.black),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              alignment: Alignment.center,
              padding: EdgeInsets.all(20.h),
              child: Column(
                children: [
                  TextField(
                    keyboardType: TextInputType.emailAddress,
                    onChanged: (value) {
                      // email = value;
                    },
                    decoration: InputDecoration(
                      hintText: 'Email',
                      labelText: 'Email',
                      // errorText: _wrongEmail ? emailText : null,
                    ),
                  ),
                  SizedBox(height: 20.0.h),
                  TextField(
                    obscureText: true,
                    keyboardType: TextInputType.visiblePassword,
                    onChanged: (value) {
                      // password = value;
                    },
                    decoration: InputDecoration(
                      hintText: 'Password',
                      labelText: 'Password',
                      // errorText: _wrongPassword ? passwordText : null,
                    ),
                  ),
                  SizedBox(height: 10.0.h),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Home()),
                      );
                    },
                    child: Container(
                      margin: EdgeInsets.only(top: 5.h),
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(15.w),
                      width: MediaQuery.of(context).size.width / 2,
                      decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(10.sp)),
                      child: Text(
                        "Sign Up",
                        style: TextStyle(
                            fontFamily: 'Poppins-Regular',
                            fontWeight: FontWeight.bold,
                            fontSize: 21.sp,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:trafic_flow_controller/constants/constants.dart';
// import 'package:trafic_flow_controller/views/LoginScreen.dart';
//
// // ignore: must_be_immutable
// class RegisterPage extends StatefulWidget {
//   static String id = '/RegisterPage';
//
//   @override
//   _RegisterPageState createState() => _RegisterPageState();
// }
//
// class _RegisterPageState extends State<RegisterPage> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         backgroundColor: Colors.white,
//         resizeToAvoidBottomInset: false,
//         body: Stack(
//           children: [
//             Align(
//               alignment: Alignment.topRight,
//               child: Image.asset('assets/images/img.png'),
//             ),
//             Padding(
//               padding: EdgeInsets.only(
//                   top: 60.0.h, bottom: 20.0.h, left: 20.0.w, right: 20.0.w),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     'Register',
//                     style: TextStyle(
//                         fontFamily: 'Poppins-Regular',
//                         fontWeight: FontWeight.bold,
//                         fontSize: 30.sp,
//                         color: Colors.black),
//                   ),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Lets get',
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 18.sp,
//                             color: Colors.black),
//                       ),
//                       Text(
//                         'you on board',
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 18.sp,
//                             color: Colors.black),
//                       ),
//                     ],
//                   ),
//                   Column(
//                     children: [
//                       TextField(
//                         keyboardType: TextInputType.name,
//                         onChanged: (value) {
//                           // name = value;
//                         },
//                         decoration: InputDecoration(
//                           hintText: 'Full Name',
//                           labelText: 'Full Name',
//                         ),
//                       ),
//                       SizedBox(height: 20.0.h),
//                       TextField(
//                         keyboardType: TextInputType.emailAddress,
//                         onChanged: (value) {
//                           // email = value;
//                         },
//                         decoration: InputDecoration(
//                           labelText: 'Email',
//                           // errorText: _wrongEmail ? _emailText : null,
//                         ),
//                       ),
//                       SizedBox(height: 20.0.h),
//                       TextField(
//                         obscureText: true,
//                         keyboardType: TextInputType.visiblePassword,
//                         onChanged: (value) {
//                           // password = value;
//                         },
//                         decoration: InputDecoration(
//                           labelText: 'Password',
//                           // errorText: _wrongPassword ? _passwordText : null,
//                         ),
//                       ),
//                       SizedBox(height: 10.0.h),
//                     ],
//                   ),
//                   GestureDetector(
//                     onTap: () {
//                       setState(() {
//                         // _wrongEmail = false;
//                         // _wrongPassword = false;
//                       });
//                     },
//                     child: Container(
//                       padding: EdgeInsets.symmetric(vertical: 10.0.h),
//                       color: kPrimaryColor,
//                       child: Text(
//                         'Register',
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 20.sp,
//                             color: Colors.white),
//                       ),
//                     ),
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Padding(
//                         padding: EdgeInsets.symmetric(horizontal: 10.0),
//                         child: Container(
//                           height: 1.0,
//                           width: 60.0,
//                           color: Colors.black87,
//                         ),
//                       ),
//                       Text(
//                         'Or',
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 20.sp,
//                             color: Colors.black),
//                       ),
//                       Padding(
//                         padding: EdgeInsets.symmetric(horizontal: 10.0),
//                         child: Container(
//                           height: 1.0,
//                           width: 60.0,
//                           color: Colors.black87,
//                         ),
//                       ),
//                     ],
//                   ),
//                   Row(
//                     children: [
//                       Expanded(
//                         child: GestureDetector(
//                           onTap: () {},
//                           child: Container(
//                             padding: EdgeInsets.symmetric(vertical: 5.0),
//                             color: Colors.white,
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: [
//                                 Image.asset('assets/images/gg.png',
//                                     fit: BoxFit.contain,
//                                     width: 40.0,
//                                     height: 40.0),
//                                 Text(
//                                   'Google',
//                                   style: TextStyle(
//                                       fontFamily: 'Poppins-Regular',
//                                       fontWeight: FontWeight.normal,
//                                       fontSize: 20.sp,
//                                       color: Colors.black),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 20.0),
//                       Expanded(
//                         child: GestureDetector(
//                           onTap: () {},
//                           child: Container(
//                             padding: EdgeInsets.symmetric(vertical: 5.0),
//                             color: Colors.white,
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: [
//                                 Image.asset('assets/images/fb.png',
//                                     fit: BoxFit.cover,
//                                     width: 40.0,
//                                     height: 40.0),
//                                 Text(
//                                   'Facebook',
//                                   style: TextStyle(
//                                       fontFamily: 'Poppins-Regular',
//                                       fontWeight: FontWeight.normal,
//                                       fontSize: 20.sp,
//                                       color: Colors.black),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Text(
//                         'Already have an account?',
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 20.sp,
//                             color: Colors.black),
//                       ),
//                       GestureDetector(
//                         onTap: () {
//                           Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                                   builder: (context) => LoginScreen()));
//                         },
//                         child: Text(
//                           ' Sign In',
//                           style: TextStyle(
//                               fontFamily: 'Poppins-Regular',
//                               fontWeight: FontWeight.normal,
//                               fontSize: 20.sp,
//                               color: Colors.blue),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ));
//   }
// }

import 'package:flutter/material.dart';
import 'package:trafic_flow_controller/views/LoginScreen.dart';
import 'package:trafic_flow_controller/views/signUpLoginPage.dart';

import 'GetStarted.dart';
import 'GetStarted1.dart';
import 'GetStarted3.dart';

class GetStartedNow extends StatefulWidget {
  const GetStartedNow({Key? key}) : super(key: key);

  @override
  State<GetStartedNow> createState() => _GetStartedNowState();
}

class _GetStartedNowState extends State<GetStartedNow> {
  List<Widget> pages = [
    const GetStarted1(),
    const GetStarted2(),
    const GetStarted3(),
    // LoginScreen(),
    // const SignupScreen(),
  ];
  int index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(children: [
      pages[index],
      Positioned(
        bottom: 40,
        right: 40,
        child: FloatingActionButton(
          highlightElevation: 30,
          backgroundColor: Colors.black,
          elevation: 10,
          onPressed: () {
            setState(() {
              if (index < 2) {
                index = index + 1;
                print(index);
              } else {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => SignUpLoginPage()),
                );
              }
            });
          },
          child: const Icon(Icons.arrow_forward_ios),
        ),
      )
    ]));
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:trafic_flow_controller/constants/constants.dart';
import 'package:trafic_flow_controller/views/Register.dart';

import 'Home.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.blue,
      body: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height / 1.7,
            padding: EdgeInsets.only(
                top: 40.h, left: 20.w, right: 20.w, bottom: 20.h),
            decoration: BoxDecoration(
                color: Colors.white,
                image: DecorationImage(
                    image:
                        AssetImage("assets/images/LoginSignUpTitleImage.png"),
                    fit: BoxFit.cover)),
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.all(50.w),
                  child: Text(
                    'Traffic Flow Control',
                    style: TextStyle(
                        fontFamily: 'Poppins-Regular',
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                        color: Colors.black),
                  ),
                ),
              ],
            ),
          ),
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.all(20.h),
            child: Column(
              children: [
                TextField(
                  keyboardType: TextInputType.emailAddress,
                  onChanged: (value) {
                    // email = value;
                  },
                  decoration: InputDecoration(
                    hintText: 'Email',
                    labelText: 'Email',
                    // errorText: _wrongEmail ? emailText : null,
                  ),
                ),
                SizedBox(height: 20.0.h),
                TextField(
                  obscureText: true,
                  keyboardType: TextInputType.visiblePassword,
                  onChanged: (value) {
                    // password = value;
                  },
                  decoration: InputDecoration(
                    hintText: 'Password',
                    labelText: 'Password',
                    // errorText: _wrongPassword ? passwordText : null,
                  ),
                ),
                SizedBox(height: 10.0.h),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Home()),
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.only(top: 5.h),
                    alignment: Alignment.center,
                    padding: EdgeInsets.all(15.w),
                    width: MediaQuery.of(context).size.width / 2,
                    decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(10.sp)),
                    child: Text(
                      "Sign In",
                      style: TextStyle(
                          fontFamily: 'Poppins-Regular',
                          fontWeight: FontWeight.bold,
                          fontSize: 21.sp,
                          color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

//======
// bool _wrongEmail = false;
// bool _wrongPassword = false;
//
// // ignore: must_be_immutable
// class LoginPage extends StatefulWidget {
//   static String id = '/LoginPage';
//
//   @override
//   _LoginPageState createState() => _LoginPageState();
// }
//
// class _LoginPageState extends State<LoginPage> {
//   late String email;
//   late String password;
//
//   bool _showSpinner = false;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         resizeToAvoidBottomInset: false,
//         backgroundColor: Colors.white,
//         body: Stack(
//           children: [
//             Align(
//               alignment: Alignment.topRight,
//               child: Container(
//                 height: 200.h,
//                 width: 200.w,
//                 decoration: BoxDecoration(
//                     image: DecorationImage(
//                         image: AssetImage('assets/images/img.png'))),
//               ),
//             ),
//             Padding(
//               padding: EdgeInsets.only(
//                   top: 60.0.h, bottom: 20.0.h, left: 20.0.w, right: 20.0.w),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     'Login',
//                     style: TextStyle(
//                         fontFamily: 'Poppins-Regular',
//                         fontWeight: FontWeight.bold,
//                         fontSize: 30.sp,
//                         color: Colors.black),
//                   ),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Welcome back,',
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 20.sp,
//                             color: Colors.black),
//                       ),
//                       Text(
//                         'please login to your account',
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 20.sp,
//                             color: Colors.black),
//                       ),
//                     ],
//                   ),
//                   Column(
//                     children: [
//                       TextField(
//                         keyboardType: TextInputType.emailAddress,
//                         onChanged: (value) {
//                           email = value;
//                         },
//                         decoration: InputDecoration(
//                           hintText: 'Email',
//                           labelText: 'Email',
//                           // errorText: _wrongEmail ? emailText : null,
//                         ),
//                       ),
//                       SizedBox(height: 20.0.h),
//                       TextField(
//                         obscureText: true,
//                         keyboardType: TextInputType.visiblePassword,
//                         onChanged: (value) {
//                           password = value;
//                         },
//                         decoration: InputDecoration(
//                           hintText: 'Password',
//                           labelText: 'Password',
//                           // errorText: _wrongPassword ? passwordText : null,
//                         ),
//                       ),
//                       SizedBox(height: 10.0.h),
//                       Align(
//                         alignment: Alignment.topRight,
//                         child: GestureDetector(
//                           onTap: () {
//                             // Navigator.pushNamed(context, ForgotPassword.id);
//                           },
//                           child: Text(
//                             'Forgot Password?',
//                             style: TextStyle(
//                                 fontFamily: 'Poppins-Regular',
//                                 fontWeight: FontWeight.normal,
//                                 fontSize: 17.sp,
//                                 color: Colors.blue),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   GestureDetector(
//                     onTap: () async {},
//                     child: Container(
//                       padding: EdgeInsets.symmetric(vertical: 10.0.h),
//                       color: kPrimaryColor,
//                       child: Text(
//                         'Login',
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 20.sp,
//                             color: Colors.white),
//                       ),
//                     ),
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Padding(
//                         padding: EdgeInsets.symmetric(horizontal: 10.0.w),
//                         child: Container(
//                           height: 1.0.h,
//                           width: 60.0.w,
//                           color: Colors.black87,
//                         ),
//                       ),
//                       Text(
//                         'Or',
//                         style: TextStyle(
//                             fontFamily: 'Poppins-Regular',
//                             fontWeight: FontWeight.normal,
//                             fontSize: 20.sp,
//                             color: Colors.black),
//                       ),
//                       Padding(
//                         padding: EdgeInsets.symmetric(horizontal: 10.0.h),
//                         child: Container(
//                           height: 1.0.h,
//                           width: 60.0.w,
//                           color: Colors.black87,
//                         ),
//                       ),
//                     ],
//                   ),
//                   Row(
//                     children: [
//                       Expanded(
//                         child: GestureDetector(
//                           onTap: () {},
//                           child: Container(
//                             padding: EdgeInsets.symmetric(vertical: 5.0.h),
//                             color: Colors.white,
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: [
//                                 Image.asset('assets/images/gg.png',
//                                     fit: BoxFit.contain,
//                                     width: 40.0.w,
//                                     height: 40.0.h),
//                                 Text(
//                                   'Google',
//                                   style: TextStyle(
//                                       fontFamily: 'Poppins-Regular',
//                                       fontWeight: FontWeight.normal,
//                                       fontSize: 20.sp,
//                                       color: Colors.black),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 20.0.w),
//                       Expanded(
//                         child: GestureDetector(
//                           onTap: () {},
//                           child: Container(
//                             padding: EdgeInsets.symmetric(vertical: 5.0.h),
//                             color: Colors.white,
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: [
//                                 Image.asset('assets/images/fb.png',
//                                     fit: BoxFit.cover,
//                                     width: 40.0.w,
//                                     height: 40.0.h),
//                                 Text(
//                                   'Facebook',
//                                   style: TextStyle(
//                                       fontFamily: 'Poppins-Regular',
//                                       fontWeight: FontWeight.normal,
//                                       fontSize: 20.sp,
//                                       color: Colors.black),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Text(
//                         'Don\'t have an account?',
//                         style: TextStyle(fontSize: 17.sp),
//                       ),
//                       GestureDetector(
//                         onTap: () {
//                           Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                                   builder: (context) => RegisterPage()));
//                         },
//                         child: Text(
//                           ' Sign Up',
//                           style: TextStyle(
//                               fontFamily: 'Poppins-Regular',
//                               fontWeight: FontWeight.normal,
//                               fontSize: 18.sp,
//                               color: Colors.blue),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ));
//   }
// }

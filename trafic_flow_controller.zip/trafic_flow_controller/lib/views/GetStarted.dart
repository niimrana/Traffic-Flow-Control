import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../constants/constants.dart';

class GetStarted1 extends StatefulWidget {
  const GetStarted1({Key? key}) : super(key: key);

  @override
  State<GetStarted1> createState() => _GetStarted1State();
}

class _GetStarted1State extends State<GetStarted1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Container(
          color: Colors.white,
          alignment: Alignment.center,
          margin: EdgeInsets.all(10.w),
          padding: EdgeInsets.all(15.w),
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.center,
            // crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                'What is Traffic Flow Control?',
                style: TextStyle(
                    fontFamily: 'Poppins-Regular',
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.black),
              ),
              Spacer(),
              Image(
                height: MediaQuery.of(context).size.height / 2,
                image: AssetImage("assets/images/GetStarted1.png"),
              ),
              Spacer(),
              Text(
                'Traffic elements. Road traffic control at its most elemental level is achieved through the use of a system of signs, signals, and markings.',
                style: TextStyle(
                    fontFamily: 'Poppins-Regular',
                    fontWeight: FontWeight.normal,
                    fontSize: 16,
                    color: Colors.black),
              ),
              Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:delayed_display/delayed_display.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:trafic_flow_controller/views/getting_started.dart';

import '../constants/constants.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    new Future.delayed(
        const Duration(seconds: 3),
        () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => GetStartedNow()),
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        padding:
            EdgeInsets.only(top: 40.h, left: 20.w, right: 20.w, bottom: 20.h),
        decoration: const BoxDecoration(
          color: Colors.blue,
        ),
        child: Column(
          children: <Widget>[
            Expanded(child: Container()),
            const Text(
              'TRAFFIC',
              style: TextStyle(
                  fontFamily: 'Poppins-Regular',
                  fontWeight: FontWeight.bold,
                  fontSize: 25,
                  color: Colors.white),
            ),
            Center(
              child: DelayedDisplay(
                delay: const Duration(seconds: 1),
                slidingCurve: Curves.easeIn,
                child: Row(
                  children: <Widget>[
                    Expanded(child: Container()),
                    const Text(
                      '\nFLOW CONTROLLER',
                      style: TextStyle(
                          fontFamily: 'Poppins-Regular',
                          fontWeight: FontWeight.normal,
                          fontSize: 19,
                          color: Colors.white),
                    ),
                    Expanded(child: Container()),
                  ],
                ),
              ),
            ),
            Expanded(child: Container()),
            const Text(
              '© Copyrights Malik',
              style: TextStyle(
                  fontFamily: 'Poppins-Regular',
                  fontWeight: FontWeight.w100,
                  fontSize: 14,
                  color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

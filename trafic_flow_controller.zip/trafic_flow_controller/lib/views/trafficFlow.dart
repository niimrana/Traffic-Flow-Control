import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TrafficFlow extends StatefulWidget {
  const TrafficFlow({Key? key}) : super(key: key);

  @override
  State<TrafficFlow> createState() => _TrafficFlowState();
}

class _TrafficFlowState extends State<TrafficFlow> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding:
            EdgeInsets.only(top: 30.h, left: 20.w, right: 20.w, bottom: 20.h),
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/images/trafficFlowFromRoads.png"),
              fit: BoxFit.fill),
        ),
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {},
                      child: Container(
                        padding: EdgeInsets.all(10.w),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(40.sp),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.2),
                              blurRadius: 10,
                              spreadRadius: 5,

                              offset: Offset(2, 2), // Shadow position
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.topRight,
                      margin: EdgeInsets.only(right: 20.w, top: 20.w),
                      width: 40.w,
                      padding: EdgeInsets.all(10.w),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10.sp),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            blurRadius: 10,
                            spreadRadius: 5,

                            offset: Offset(2, 2), // Shadow position
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Image(
                            image: AssetImage("assets/images/homeIcon1.png"),
                          ),
                          SizedBox(
                            height: 20.h,
                          ),
                          Image(
                            image: AssetImage("assets/images/compass.png"),
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
            Spacer(),
            Text(
              '    Siri Suggestion',
              style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
            ),
            Container(
              padding: EdgeInsets.all(10.w),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.sp)),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(10.w),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20.w),
                    ),
                    child: Icon(
                      Icons.car_repair,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    width: 10.w,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Parked Car',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16.sp),
                      ),
                      Text(
                        '290m away, near DHA Phase 1',
                        style: TextStyle(
                            fontWeight: FontWeight.normal, fontSize: 14.sp),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Container(
              // color: Theme.of(context).primaryColor,
              width: MediaQuery.of(context).size.width,
              child: new Card(
                child: new ListTile(
                  leading: new Icon(Icons.search),
                  title: new TextField(
                    // controller: controller,
                    decoration: new InputDecoration(
                        hintText: 'Search', border: InputBorder.none),
                    // onChanged: onSearchTextChanged,
                  ),
                  trailing: new IconButton(
                    icon: new Icon(Icons.abc_sharp),
                    onPressed: () {
                      // controller.clear();
                      // onSearchTextChanged('');
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

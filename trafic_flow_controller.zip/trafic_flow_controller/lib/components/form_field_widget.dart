import 'package:flutter/material.dart';

// ignore: must_be_immutable
class MyTextFormField extends StatelessWidget {
  MyTextFormField({
    Key? key,
    this.hintText,
    this.icon,
    this.obsecureText,
    this.keyBoardType,
  }) : super(key: key);

  String? hintText;
  Icon? icon;
  bool? obsecureText;
  TextInputType? keyBoardType;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 16),
      // padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.grey[200],
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          obscureText: obsecureText ?? false,
          keyboardType: keyBoardType,
          autofocus: true,

          // style: TextStyle(color: Colors.pink),
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.all(15.0),
            border: InputBorder.none,
            suffixIcon: icon,
            hintText: hintText ?? '',
          ),
        ),
      ),
    );
  }
}

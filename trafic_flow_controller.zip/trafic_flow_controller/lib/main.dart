import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:trafic_flow_controller/views/Automation.dart';
import 'package:trafic_flow_controller/views/CongestionManagement.dart';
import 'package:trafic_flow_controller/views/GetStarted.dart';
import 'package:trafic_flow_controller/views/Home.dart';
import 'package:trafic_flow_controller/views/LoginScreen.dart';
import 'package:trafic_flow_controller/views/Register.dart';
import 'package:trafic_flow_controller/views/Roads.dart';
import 'package:trafic_flow_controller/views/ViewTraffic.dart';
import 'package:trafic_flow_controller/views/selectRoad.dart';
import 'package:trafic_flow_controller/views/signUpLoginPage.dart';
import 'package:trafic_flow_controller/views/splash_screen.dart';
import 'package:trafic_flow_controller/views/trafficFlow.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 800),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'TFC',
          home: SplashScreen(),
        );
      },
      // child: const VerificationScreen(),
    );
  }
}
